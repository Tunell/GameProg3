#include "Game.h"

int main(int argc, char** argv){
	Engine::Game game;
	return 0;
}